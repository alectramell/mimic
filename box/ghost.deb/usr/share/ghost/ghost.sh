#!/bin/bash

clear

gnome-terminal --full-screen &

clear

